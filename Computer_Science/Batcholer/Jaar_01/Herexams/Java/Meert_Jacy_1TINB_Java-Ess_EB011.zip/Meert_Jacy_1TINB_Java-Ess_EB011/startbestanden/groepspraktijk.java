package startbestanden;

public class groepspraktijk implements Toonbaar{

    private String adres;
    private String naam;
    private String telefoonnummer;
    private Dokter[] dokters = new Dokter[0];
    private Patient[] patienten = new Patient[0];


    public groepspraktijk(String adres, String naam, String telefoonnummer){
        this.adres = adres;
        this.naam = naam;
        this.telefoonnummer = telefoonnummer;
    }
    @Override
    public void toonAgenda() {
    }

    public void toonPatient() {
    }

    public void voegDokterToe(Dokter... dokter) {
        int openPlaatsen = 0;
        for (Dokter value : this.dokters) {
            if (value == null) {
                openPlaatsen++;
            }
        }

        if (openPlaatsen < dokter.length) {
            System.out.println("De dokters zijn niet toegevoegd want er is niet voldoende plaats in de groepspraktijk");
        } else {
            int eersteOpenPlaats = 0;
            for (int i = 0; i < this.dokters.length; i++) {
                if (this.dokters[i] == null) {
                    eersteOpenPlaats = i;
                    i = this.dokters.length;
                }
            }
            int count = 0;
            for (int i = eersteOpenPlaats; i < dokter.length; i++) {
                this.dokters[i] = dokter[count];
                count++;
            }
        }
    }

    public void voegPatientToe(Patient... patient) {
        int openPlaatsen = 0;
        for (Patient value : this.patienten) {
            if (value == null) {
                openPlaatsen++;
            }
        }

        if (openPlaatsen < patient.length) {
            System.out.println("geen ruimte meer voor patient");
        } else {
            int eersteOpenPlaats = 0;
            for (int i = 0; i < this.patienten.length; i++) {
                if (this.patienten[i] == null) {
                    eersteOpenPlaats = i;
                    i = this.patienten.length;
                }
            }
            int count = 0;
            for (int i = eersteOpenPlaats; i < patient.length; i++) {
                this.patienten[i] = patient[count];
                count++;
            }
        }
    }

    @Override
    public String toString(){
        return this.naam + " Adres: " + this.adres + " Tel: " + this.telefoonnummer;
    }
}
