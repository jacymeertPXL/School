package startbestanden;

import java.time.LocalTime;
import java.util.ArrayList;

public class Data {

    public static ArrayList<Dokter> maakLijstDokters() {
      Dokter alain = new Dokter("Alain Kreemers", "17/5/1988",
                LocalTime.of(8, 0, 0), 20, 8, new String[]{"maandag", "vrijdag"});

       Dokter sofie = new Dokter("Sofie Maes",
                "1/12/1976",
                LocalTime.of(14, 0, 0), 30, 6, new String[]{"woensdag", "vrijdag"});
       Dokter mo = new Dokter("Mo Amir",
                "4/8/1980",
                LocalTime.of(18, 0, 0),
                15, 10, new String[]{"woensdag", "donderdag", "vrijdag"});
        //ToDo maak een ArrayList van dokters en plaats dokter alain, sofie en mo in deze ArrayList
        return null;
    }

    public static ArrayList<Patient> maakLijstPatienten() {
        String[] naam = {"Peter Bueken", "Hugo Van de Vel", "Jo Teugels", "Mo Mommaerts", "Sara Warrinier",
                "Filip Vanroosen", "Louis Vanharen", "Matty Cauwenberhgs", "Erica Hollevoet", "An Peeters", "Lieve Put",
                "Semih Kenes", "Herman Abts"};
        String[] geboortedatum = {"27/5/1994", "10/11/1940", "12/08/1974", "3/02/1969",
                "5/05/1976", "5/08/2007", "15/05/1980", "22/12/1990", "11/04/1997",
                "13/03/1995", "24/09/1982", "13/07/1987", "1/5/1986"};

        // ToDo maak patiënten met bovenstaande arrays en plaats deze in een arraylist
        return null;
    }
}
