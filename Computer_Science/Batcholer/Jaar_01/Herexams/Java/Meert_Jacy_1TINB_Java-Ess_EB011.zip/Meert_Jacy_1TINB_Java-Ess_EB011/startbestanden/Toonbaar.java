package startbestanden;

public interface Toonbaar {
    void toonAgenda();
}
