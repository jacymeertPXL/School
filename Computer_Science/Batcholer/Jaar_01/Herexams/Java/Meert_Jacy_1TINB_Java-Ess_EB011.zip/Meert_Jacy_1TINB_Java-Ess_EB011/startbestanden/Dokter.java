package startbestanden;


import java.time.LocalTime;
import java.util.Arrays;

public class Dokter extends Persoon implements Toonbaar{
    private final LocalTime starttijd;
    private final static int MAX_AANTAL_DAGEN = 5;
    private final Integer duur;
    private final Integer maxAantalAfspraken;
    private final String[] dagen = new dagen[this.MAX_AANTAL_DAGEN];
    private String[][] afspraken;


    public Dokter(String naam, String afspraken, LocalTime startijd, Integer duur, Integer maxAantalAfspraken, String[] dagen){
        super(naam);
        this.starttijd = startijd;
        this.duur = duur;
        this.maxAantalAfspraken = maxAantalAfspraken;
        this.dagen[0] = Arrays.toString(dagen);
        this.afspraken[0][0] = Arrays.toString(new String[]{afspraken});
    }

    public String[][] GetAfspraken() {
        return this.afspraken;
    }
    public String[] GetDagen() {
        return this.dagen;
    }
    public Integer getDuur() {
        return duur;
    }
    public void getKolomDag(String dagen){

    }
    public LocalTime getStarttijd() {
        return starttijd;
    }

    public void maakAfspraak(Patient patient, LocalTime starttijd, String bericht){

    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public void toonAgenda() {
    }
}
