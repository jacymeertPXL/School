﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QXLClassLibirary.Models
{
    public class Vraag : IVraagbaar
    {
        public Vraag(int id, string tekst, int vakId)
        {
            Id = id;
            Tekst = tekst;
            VakId = vakId;
        }
        public int Id { get; set; }
        public string Stelvraag {  get; }
        public string Tekst { get; set; }
        public int VakId { get; set; }


    }
}
