﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QXLClassLibirary.DataAcces
{
    public static class SpelerData
    {
        private static DataSet spelerDataSet = new DataSet();

        private static readonly DataTable spelerDataTable = new DataTable();

        private static readonly DataTable fouteVragenDataTable = new DataTable();

        public static void OpenSpelerData()
        {
            spelerDataTable.Clear();
            using (StreamReader sr = new StreamReader("bin/Debug/SpelerData.xml"))
            {
                string[] headers = sr.ReadLine().Split(';');
                foreach (string header in headers)
                {

                    spelerDataTable.Columns.Add(header);
                }
                while (!sr.EndOfStream)
                {
                    spelerDataTable.Rows.Add(sr.ReadLine().Split(';'));
                }

                if (spelerDataSet.Tables.Contains(spelerDataTable.ToString()))
                {

                }
                else
                {
                    InialiseerSpelerData();
                }

                if (spelerDataSet.Tables.Contains(fouteVragenDataTable.ToString()))
                {

                }
                else
                {
                    InialiseerSpelerData();
                }

            }
        }
        public static void InialiseerSpelerData()
        {
            DataTable Spelers = new DataTable("Spelers");

            DataColumn Id = new DataColumn();
            Id.ColumnName = "Id";
            Id.DataType = typeof(int);
            Id.Unique = true;
            Id.AllowDBNull = false;
            Id.AutoIncrement = true;

            DataColumn Naam = new DataColumn();
            Naam.ColumnName = "Naam";
            Naam.DataType = typeof(string);
            Naam.Unique = true;
            Naam.AllowDBNull = false;

            DataColumn Wachtwoord = new DataColumn();
            Wachtwoord.ColumnName = "Wachtwoord";
            Wachtwoord.DataType = typeof(string);
            Wachtwoord.AllowDBNull = false;

            Spelers.PrimaryKey = new DataColumn[] { Spelers.Columns["Id"] };

            Spelers.Columns.Add(Id);
            Spelers.Columns.Add(Naam);
            Spelers.Columns.Add(Wachtwoord);

            spelerDataSet.Merge(Spelers);
        }
        public static void InialiseerFouteVragen()
        {
            DataTable FouteVragen = new DataTable("FouteVragen");

            DataColumn Id = new DataColumn();
            Id.ColumnName = "Id";
            Id.DataType = typeof(int);
            Id.AutoIncrement = true;


            DataColumn Spelerid = new DataColumn();
            Spelerid.ColumnName = "Naam";
            Spelerid.DataType = typeof(int);


            DataColumn Vraagid = new DataColumn();
            Vraagid.ColumnName = "Wachtwoord";
            Vraagid.DataType = typeof(int);


            FouteVragen.PrimaryKey = new DataColumn[] { FouteVragen.Columns["Id"] };

            FouteVragen.Columns.Add(Id);
            FouteVragen.Columns.Add(Spelerid);
            FouteVragen.Columns.Add(Vraagid);

            spelerDataSet.Merge(FouteVragen);
        }

        public static void SlaSpelerDataOp()
        {
            SaveFileDialog sfd = new SaveFileDialog
            {
                Filter = "XML Files (*.xml)|*.xml",
                FileName = "spelerData.xml"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                spelerDataSet.WriteXml(sfd.FileName);
            }
        }

        public static void RegistreerSpeler(string gebruiker, string wachtwoord)
        {
            DataRow newRow = spelerDataTable.NewRow();

            newRow["Gebruiker"] = gebruiker;
            newRow["Wachtwoord"] = wachtwoord; 

            int maxId = spelerDataTable.AsEnumerable().Max(r => Convert.ToInt32(r["ID"]));

            newRow["ID"] = maxId + 1;

            spelerDataTable.Rows.Add(newRow);
        }

        public static Boolean IsGeldigeLogin(string gebruiker, string wachtwoord)
        {
            return spelerDataTable.AsEnumerable().Any(r => r["Gebruiker"].ToString() == gebruiker && r["Wachtwoord"].ToString() == wachtwoord);
        }

        public static int GeefIdVanNaam(string naam)
        {
            return spelerDataTable.AsEnumerable().FirstOrDefault(r =>
            {
                if (r is null)
                {
                    throw new ArgumentNullException(nameof(r));
                }

                return r["Naam"].ToString() == naam;
            }) ? Convert.ToInt32(["Id"]) : -1;
        }

        public static void VoegFoutToe(string vraagid, string spelerid)
        {
            DataRow newRow = fouteVragenDataTable.NewRow();

            newRow["Vraag"] = vraagid;
            newRow["Id"] = spelerid;

            int maxId = spelerDataTable.AsEnumerable().Max(r => Convert.ToInt32(r["ID"]));

            newRow["ID"] = maxId + 1;

            spelerDataTable.Rows.Add(newRow);

        }

        public static List<int> GeefAlleFouteVragenVoorSpelederId(int id)
        {
            var fouteVragen = spelerDataTable.AsEnumerable()
                .Where(r => r["Id"] == id.ToString())
                .Select(r => Convert.ToInt32(r["VakId"]))
                .ToList();

            return fouteVragen;
        }


    }

}
