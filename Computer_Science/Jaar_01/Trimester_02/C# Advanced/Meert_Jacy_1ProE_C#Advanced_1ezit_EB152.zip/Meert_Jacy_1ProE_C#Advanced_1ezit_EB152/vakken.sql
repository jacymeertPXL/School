-- Maak de tabel vakken aan.
CREATE TABLE vakken (
    id INT PRIMARY KEY,
    naam VARCHAR(255),
    pijler VARCHAR(255)
);

-- Voeg drie vakken toe.
INSERT INTO vakken (id, naam, pijler) VALUES
(1, 'C# Web 1', 'Software Development'),
(2, 'Security & Privacy', 'Data'),
(3, 'Communication Skills', 'Communicatie');
