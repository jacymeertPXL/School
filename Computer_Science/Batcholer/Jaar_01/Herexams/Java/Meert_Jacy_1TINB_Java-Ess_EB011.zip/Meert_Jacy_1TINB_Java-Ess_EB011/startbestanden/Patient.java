package startbestanden;

import java.util.Objects;

public class Patient extends Persoon{

    private String patientID;
    private Dokter huisarts;
    public Patient(String naam, String patientID, Dokter huisarts){
        super(naam);
        this.patientID = patientID;
        this.huisarts = huisarts;
    }


    public String getPatientID() {
        return patientID;
    }

    public Dokter getHuisarts() {
        return huisarts;
    }

    public void setHuisarts(Dokter huisarts) {
        this.huisarts = huisarts;
    }

    public String bepaalpatientID() {

        int spaceIndex = getNaam().indexOf(' ');

        if (spaceIndex == -1) {
            return getPatientIdWithoutSpaces(getNaam());
        } else {
            String lastName = getNaam().substring(spaceIndex);
            return getPatientIdWithoutSpaces(getNaam().substring(0, spaceIndex));
        }
    }

    private String getPatientIdWithoutSpaces(String name) {
        String firstName;
        if (Character.isSpaceChar(name.charAt(0))) {
            firstName = Character.toUpperCase(name.charAt(0)) + name.substring(1);
        } else {
            firstName = Character.toUpperCase(name.charAt(0)) + name.substring(1).toLowerCase();
        }
        int letterCount = 0;
        for (char c : firstName.toCharArray()) {
            if (!Character.isLetter(c)) continue;
            ++letterCount;
        }
        firstName = firstName + letterCount;
        return firstName;
    }

    @Override
    public int hashCode() {
        return Objects.hash(patientID, huisarts);
    }

    @Override
    public boolean equals(Object object) {
        if (object instanceof Persoon temp) {
            return this.getNaam().equals(temp.getNaam());
        }
        return false;
    }

    @Override
    public String toString() {
        return this.patientID + " " + this.huisarts;
    }
}
