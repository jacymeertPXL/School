﻿using QXLClassLibirary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace QXLClassLibirary.DataAcces
{
    public static class VakData
    {
        public static List<Vraag> vragen { get; set; }

        private static SqlConnection GetConnection()
        {
            return new SqlConnection(@"Integrated Security = SSPI;ersist Security Info = False; Initial Catalog = MedewerkersData Source = localhost\SQLEXPRESS");
        }

        public static void LeesVragenUitBestand(string bestandPad)
        {
            string[] lines = File.ReadAllLines(bestandPad);
            List<Vraag> vragen = new List<Vraag>();

            foreach (string line in lines.Skip(1)) 
            {
                string[] columns = line.Split(',');
                Vraag vraag;

                switch (columns[0])
                {
                    case "OpenVraag":
                        vraag = new OpenVraag(int.Parse(columns[1]), int.Parse(columns[2]), columns[3], columns[4]);
                        break;
                    case "MulptipelChoice":
                        vraag = new MultipleChoiceVraag(
                            int.Parse(columns[1]),
                            int.Parse(columns[2]),
                            columns[3],
                            columns[4],
                            columns[5],
                            columns[6],
                            columns[7],
                            int.Parse(columns[8])
                        );
                        break;
                    default:
                        throw new ArgumentException("Unknown question type");
                }

                vragen.Add(vraag);
            }
        }

        public static List<Vak> GetVakken()
        {
            using (SqlConnection conn = GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM vakken", conn);
                SqlDataReader reader = cmd.ExecuteReader();

                List<Vak> vakken = new List<Vak>();

                while (reader.Read())
                {
                    Vak vak = new Vak
                    {
                        Id = Convert.ToInt32(reader["id"]),
                        Naam = reader["naam"].ToString(),
                        Pijler = reader["pijler"].ToString(),

                    };
                    vakken.Add(vak);
                }

                reader.Close();
                conn.Close();

                return vakken;
            }
        }

        public static List<Vraag> GetVragenPerVak(Vak vak)
        {
            return vragen.Where(v => v.VakId == vak.Id).ToList();
        }

        public static List<Vraag> GetVragenVoorlds(List<int> vraagid)
        {
            return vragen.Where(v => vraagid.Contains(v.Id)).ToList();
        }

    }
}   
