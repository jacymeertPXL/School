﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;
using QXLClassLibirary.DataAcces;
using QXLClassLibirary.Models;

namespace QuizXLWPF
{
    /// <summary>
    /// Interaction logic for KwisWindow.xaml
    /// </summary>
    public partial class KwisWindow : Window
    {
        private List<Vraag> vragenVoorGeselecteerdVak;
        private Vraag huidigevraag;
        private int spelerId;

        public KwisWindow()
        {
            InitializeComponent();
            
        }


        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "Alle bestanden (*.*)|*.*|Tekstbestanden (*.csv) |*.csv",
                FilterIndex = 2,
                FileName = "vragen.csv",
                Multiselect = false,
                InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
            };
            VakData.LeesVragenUitBestand(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));
        }

        private void LaadVolgendeVraag()
        {
            if (vragenVoorGeselecteerdVak.Count == 0)
                return;

            Vraag huidigeVraag = vragenVoorGeselecteerdVak[new Random().Next(vragenVoorGeselecteerdVak.Count)];
            TxtVraag.Text = huidigeVraag.Stelvraag;

            if (huidigeVraag is OpenVraag)
            {
                StackPanelOpenVraag.Visibility = Visibility.Visible;
                StackPanelRadioButtons.Visibility = Visibility.Hidden;
            }
            else if (huidigeVraag is )
            {
                StackPanelOpenVraag.Visibility = Visibility.Hidden;
                StackPanelRadioButtons.Visibility = Visibility.Visible;

                RadioButton[] radioButtons = new RadioButton[4];
                for (int i = 0; i < 4; i++)
                {
                    string answerText = ((MulptipleChoiceVraag)huidigeVraag).Antwoorden[i].Text;
                    RadioButton radioButton = new RadioButton { Content = answerText };
                    radioButtons[i] = radioButton;

                   
                    radioButton.Checked += (sender, e) =>
                    {
                        
                    };

                    StackPanelRadioButtons.Children.Add(radioButton);
                }
            }
        }

        private void IsAntwoordCorrect()
        {

        }

        private void BtnVolgendeVraag_Click(object sender, RoutedEventArgs e)
        {
            IsAntwoordCorrect();
            laadVolgendeVraag();
        }

        private void BtnToonFouten_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void BtnToonFoutenMoeilijk_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnToonAntwoord_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CbxVakken_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            vragenVoorGeselecteerdVak = VakData.GetVragenPerVak((Vak)CbxVakken.SelectedItem.ToString().Trim());
            BtnStart.Visibility = Visibility.Visible;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Close();
        }
    }
}
