let tijd = new Date(1681100000000);
console.log(tijd.toLocaleString("be-BE"));

