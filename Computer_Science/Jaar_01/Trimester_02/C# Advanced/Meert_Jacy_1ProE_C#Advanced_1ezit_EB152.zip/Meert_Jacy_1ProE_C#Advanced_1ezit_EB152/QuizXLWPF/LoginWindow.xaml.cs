﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using QXLClassLibirary.DataAcces;
using QXLClassLibirary.Models;

namespace QuizXLWPF
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if(SpelerData.IsGeldigeLogin(TxtNaam.Text, PasswordBoxtekst.Password) == true)
            {
               Close();
               KwisWindow kwisWindow = new KwisWindow();
               kwisWindow.Show();
            }
            else
            {
                string bericht = "Je inloggegevens zijn incorrect";
                MessageBox.Show(bericht, " Ongeldige login", MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }

        private void BtnRegistreer_Click(object sender, RoutedEventArgs e)
        {
            if (SpelerData.GeefIdVanNaam(TxtNaam.Text) == 1)
            {
                SpelerData.RegistreerSpeler(TxtNaam.Text, PasswordBoxtekst.Password);
            }
            else
            {
                string bericht = "Deze gebruikersnaam is reeds in gebruik";
                MessageBox.Show(bericht, "Kies een andere naam", MessageBoxButton.OK);
            }
        }
    }
}
