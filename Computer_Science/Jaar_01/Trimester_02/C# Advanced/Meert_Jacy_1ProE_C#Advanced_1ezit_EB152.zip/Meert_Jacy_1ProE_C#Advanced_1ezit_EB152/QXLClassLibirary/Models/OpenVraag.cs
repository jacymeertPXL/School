﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QXLClassLibirary.Models
{
    public class OpenVraag : Vraag
    {
        //public OpenVraag(int v1, int v2, string v3, string v4)
        //{
        //}

        public OpenVraag(string antwoord, string stelvraag, int id, string tekst, int vakId) : base(id, tekst, vakId)
        {
            Antwoord = antwoord;
            Tekst = stelvraag;
        }

        public string Antwoord { get; set; }
        public string Stelvraag { get; }
    }
}
