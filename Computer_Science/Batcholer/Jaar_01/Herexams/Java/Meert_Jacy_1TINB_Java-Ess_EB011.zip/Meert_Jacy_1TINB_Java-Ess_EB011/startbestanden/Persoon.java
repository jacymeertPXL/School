package startbestanden;

import java.time.LocalDate;

public class Persoon {
    private String naam;
    private LocalDate geboortedatum;

    private Persoon(String naam, String geboortedatum){
        this.naam = naam;
        this.geboortedatum = LocalDate.parse(geboortedatum);
    }

    public Persoon(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public LocalDate getGeboortedatum() {
        return geboortedatum;
    }

    public void setGeboortedatum(LocalDate geboortedatum) {
        this.geboortedatum = geboortedatum;
    }

    @Override
    public String toString() {
        return this.naam + " " + this.geboortedatum;
    }
}
