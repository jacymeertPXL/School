// naam: Jacy meert 1TINB
function maakGebruiker(naam, nummerplaat){
    return { id: 4, naam: "nieuw", nummerplaat: "nieuw" }
}

const RegestratieBtn = document.getElementById('button_nieuwe_gebruiker');
RegestratieBtn.addEventListener('click', () => {
    Regestratiebruiker()
});

window.addEventListener("load", loaded);
function loaded() {
}
function makeElementEmpty(element) {
    while (element.hasChildNodes()) {
        element.removeChild(element.firstChild);
    }
}
function Regestratiebruiker(){
    let url = 'http://localhost:3000/gebruiker/';
    let output = document.getElementById("div_output");
    makeElementEmpty(output);
    let nummerplaat = document.getElementById("input_nummerplaat").value;
    let name = document.getElementById("input_naam").value;
    if (name.length > 2){
        let person = {name: name, nummerplaat: nummerplaat};
        fetch(url,
            {
                method: "POST",
                body: JSON.stringify(person),
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then((response) => {
                if (response.status == 201) {
                    return response.json();
                } else {
                    throw `error with status ${response.status}`;
                }
            })
            .then((person) => {
                let data = [];
                data.push([person.id ,person.name, person.nummerplaat]);
                let informatie = document.createElement("p");
                informatie.appendChild(data)
                output.appendChild(informatie);
            })
            .catch((error) => {
                output.appendChild(document.createTextNode(error));
            });
    }else{
        let tekst = "Foutieve ingave"
        let informatie = document.createElement("p");
        informatie.appendChild(tekst)
        output.appendChild(informatie);
    }

}

