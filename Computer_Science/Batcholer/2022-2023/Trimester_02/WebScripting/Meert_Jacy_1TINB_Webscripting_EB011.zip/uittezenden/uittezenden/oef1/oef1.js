// naam: Jacy Meert 1TINB

// de code voor de klassen van oef1 plaats je hieronder

class Produkt {
    constructor(_naam, _prijs) {
        if (!Number.isInteger(_prijs) || _prijs <= 0) {
            throw new Error('Foutieve ingave voor prijs');
        }
        if (typeof _naam !== 'string' || _naam.length > 2) {
            throw new Error('Foutieve ingave voor naam');
        }
        this._naam = _naam;
        this._prijs = _prijs;
    }
    get prijs() {
        return this._prijs;
    }
    get naam() {
        return this._naam;
    }
    set naam(value) {
        this._naam = value;
    }
    set prijs(value) {
        this._prijs = value;
    }

}

class Bestellingsonderdeel extends Produkt{
}

class Aankoop extends Bestellingsonderdeel {
    constructor(_aantal, _produkt, _naam, _prijs) {
        super(_naam, _prijs);
        if (!Number.isInteger(_aantal) || _aantal <= 0) {
            throw new Error('Foutieve ingave voor aantal');
        }
        if (typeof _produkt !== "object") {
            throw new Error('Foutieve ingave voor product');
        }
        this._aantal = _aantal;
        this._produkt = _produkt;
    }
    get aantal() {
        return this._aantal;
    }
    get produkt() {
        return this._produkt;
    }
    set produkt(value) {

        this._produkt = value;
    }
    set aantal(value) {

        this._aantal = value;
    }
}

class ProcentueleKorting extends Bestellingsonderdeel{
    constructor(_kortingProcent, _naam, _prijs){
        super(_naam, _prijs);
        if (!Number.isInteger(_kortingProcent) || _kortingProcent >= 0 ||_kortingProcent <= 100) {
            throw new Error('Invalid hourly wage');
        }
        this._kortingProcent=_kortingProcent;
    }
    set kortingProcent(value) {
        this._kortingProcent = value;
    }
}

class Bestelling extends Bestellingsonderdeel, Aankoop{
    constructor(_Bestellingsonderdeel, _naam, _prijs,_aantal, _produkt){
        super(_naam, _prijs,_aantal, _produkt);
        if (!Array.isArray(_Bestellingsonderdeel)) {
            throw new Error('\'Foutieve ingave voor Bestellingsonderdeel');
        }
        this._Bestellingsonderdeel= [];
    }

    voegToe(_Bestellingsonderdeel) {
        if (!(_Bestellingsonderdeel instanceof _Bestellingsonderdeel)) {
            throw new Error('\'Foutieve ingave voor Bestellingsonderdeel');
        }
        this._Bestellingsonderdeel.push(_Bestellingsonderdeel);
    }

    berekenPrijs() {
        let totaleKorting = 0;
        for (const _Bestellingsonderdeel of this._kortingProcent) {
            totaleKorting += _Bestellingsonderdeel.berekenPrijs();
        }
        const aantal = this._aantal;
        const prijs = this._prijs;
        let totalePrijs = aantal * prijs;
        let resultaat = totalePrijs * (1 - totaleKorting / 100);
        if(resultaat <= 0){
            resultaat = 0;
        }
        return resultaat;
    }
}

// de onderstaande code bevat het hoofdprogramma en laat je ongewijzigd

let produkt1=new Produkt("krant",3.55);
let produkt2=new Produkt("snoep",2.33);
let bestelling=newBestelling();
let bestellingsonderdeel1=new Aankoop(2,produkt1);
let bestellingsonderdeel2=new Aankoop(14,produkt2);
let bestellingsonderdeel3=new ProcentueleKorting(22.2);
let bestellingsonderdeel4=new ProcentueleKorting(11.4);
bestelling.voegToe(bestellingsonderdeel1);
bestelling.voegToe(bestellingsonderdeel2);
bestelling.voegToe(bestellingsonderdeel3);
bestelling.voegToe(bestellingsonderdeel4);
console.log(bestelling.berekenPrijs());

