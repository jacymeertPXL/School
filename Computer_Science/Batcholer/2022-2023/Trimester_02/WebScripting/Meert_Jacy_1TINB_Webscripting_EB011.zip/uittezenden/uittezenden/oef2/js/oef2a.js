// naam: Jacy Meert 1 TINB

const ToonBtn = document.getElementById('button_toon_filter');
const VerstopBtn = document.getElementById('button_verstop_filter');
const RegestratieBtn = document.getElementById('button_get_registraties');

ToonBtn.addEventListener('click', () => {
    ToonBtn.display.hidden;
    VerstopBtn.display.block;
});
VerstopBtn.addEventListener('click', () => {
    ToonBtn.display.block;
    VerstopBtn.display.hidden;
});
RegestratieBtn.addEventListener('click', () => {
    toongebruiker()
});
function geefRegistraties(){
    return [
        { id: 1, gebruiker_id : 1, tijd: 1681100000000 },
        { id: 2, gebruiker_id : 1, tijd: 1681200000000 },
        { id: 3, gebruiker_id : 2, tijd: 1691100000000 }                
  ]
}

function geefGebruikers(){
    return [
        { id: 1,  naam: "tim",    nummerplaat: "1-AQK-834" },
        { id: 2,  naam: "sofie",  nummerplaat: "TNA-665" },
        { id: 3,  naam: "tim",    nummerplaat: "0-CPM-771" }
    ]
}


function toongebruiker(){
    let naam = document.getElementById("test");

    if (!naam == null){
        fetch(`http://localhost:3000/gebruiker/?naam=${naam}`)
            .then((response) => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw `error with status ${response.status}`;
                }
            })
            .then((personen) => {
                for(let persoon of personen){
                    let id = persoon.id
                    fetch(`http://localhost:3000/registratie?gebruiker_id=${id}`).then((response) => {
                        if (response.ok) {
                            return response.json();
                            let paragraaf = document.createElement("p");
                            paragraaf.appendChild(document.createTextNode(personen))
                        } else {
                            throw `error with status ${response.status}`;
                        }
                    }).then((registraties)=>{
                        let {push} = [];
                        push([registraties.id, registraties.naam, registraties.nummerplaat]);
                        console.log(registraties);
                        for(let registratie of registraties){
                            console.log(registraties);
                        }
                    })
                }
            })
            .catch((error) => {
                console.log(error);
            });
    }else {
        fetch('http://localhost:3000/gebruiker/')
            .then((response) => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw `error with status ${response.status}`;
                }
            })
            .then((personen) => {
                for(let persoon of personen){
                    let id = persoon.id
                    fetch(`http://localhost:3000/registratie?gebruiker_id=${id}`).then((response) => {
                        if (response.ok) {
                            let paragraaf = document.createElement("p");
                            paragraaf.appendChild(document.createTextNode(personen))
                            return response.json();
                        } else {
                            throw `error with status ${response.status}`;
                        }
                    }).then((registraties)=>{
                        let {push} = [];
                        push([registraties.id, registraties.naam, registraties.nummerplaat]);
                        console.log(registraties);
                        for(let registratie of registraties){
                            console.log(registraties);
                        }
                    })
                }
            })
            .catch((error) => {
                console.log(error);
            });
    }
}

window.addEventListener("load", loaded);
function loaded() {
}
function makeElementEmpty(element) {
    while (element.hasChildNodes()) {
        element.removeChild(element.firstChild);
    }
}

