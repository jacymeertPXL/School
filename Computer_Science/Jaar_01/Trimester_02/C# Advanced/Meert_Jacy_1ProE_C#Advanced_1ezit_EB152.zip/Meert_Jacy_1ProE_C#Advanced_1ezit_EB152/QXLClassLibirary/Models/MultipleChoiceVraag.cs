﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QXLClassLibirary.Models
{
    public class MultipleChoiceVraag : Vraag
    {

        public MultipleChoiceVraag(string antwoordA, string antwoordB, string antwoordC, string antwoordD, string correcteOptie, string stelvraag, int id, string tekst, int vakId) : base(id, tekst, vakId)
        {
            AntwoordA = antwoordA;
            AntwoordB = antwoordB;
            AntwoordC = antwoordC;
            AntwoordD = antwoordD;
            CorrecteOptie = correcteOptie;
            Stelvraag = stelvraag;
        }

        //public MultipleChoiceVraag(int v1, int v2, string v3, string v4, string v5, string v6, string v7, int v8)
        //{
        //}

        public string AntwoordA { get; set; }
        public string AntwoordB { get; set; }
        public string AntwoordC { get; set; }
        public string AntwoordD { get; set; }
        public string CorrecteOptie { get; set; }

        private string Stelvraag;

        public string stelvraag
        {
            get { return Tekst + "/n" + AntwoordA + "/n" + AntwoordB + "/n" + AntwoordC + "/n" + AntwoordD; }
        }

    }
}
