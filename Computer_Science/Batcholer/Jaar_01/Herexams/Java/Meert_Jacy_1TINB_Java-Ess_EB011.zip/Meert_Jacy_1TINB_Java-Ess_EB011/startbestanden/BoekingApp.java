package startbestanden;

public class BoekingApp {
    public static void main(String[] args) {
        //ToDo in arraylist dokters plaats je de dokters die je in de klasse Data terugvindt

        //ToDo in arraylist patienten plaats je de patienten die je in de klasse Data terugvindt

        //TODo maak een groepspraktijk aan

        //ToDo voeg alle dokters toe aan de groepspraktijk

        //ToDo voeg alle patiënten toe aan de groepspraktijk en ken aan elke patiênt een willekeurige dokter toe.

        //ToDo druk alle patiënten en hun bijhorende arts af.

        // ToDo ingave van de patiënten en maken van afspraken


    }
}
