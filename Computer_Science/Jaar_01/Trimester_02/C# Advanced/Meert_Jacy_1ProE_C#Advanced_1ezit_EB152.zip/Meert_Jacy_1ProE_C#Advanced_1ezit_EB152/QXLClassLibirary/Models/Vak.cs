﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace QXLClassLibirary.Models
{
    public class Vak
    {
        public Vak(int id, string naam, string pijler)
        {
            Id = id;
            Naam = naam;
            Pijler = pijler;
        }
        public int Id { get; set; }
        public string Naam { get; set; }
        public string Pijler { get; set; }
        public List<Vraag> vragen { get; set; }

        public override string ToString()
        {
            return Naam;
        }

    }
}
